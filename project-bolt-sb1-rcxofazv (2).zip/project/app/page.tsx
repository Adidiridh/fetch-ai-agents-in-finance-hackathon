'use client';

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Lock, BarChart3, Glasses, Video, Network } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-primary/5 via-primary/10 to-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-5xl sm:text-7xl font-bold tracking-tight bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
              Synapse AI
            </h1>
            <p className="mt-4 text-2xl font-semibold text-primary">
              The Future of Research & AI Interaction
            </p>
            <p className="mt-6 text-xl text-muted-foreground max-w-3xl mx-auto">
              Beyond AI Chat – Your AI-Verified Research Powerhouse. Experience the revolution in AI-powered research, verification, and immersive AI interactions.
            </p>
            <div className="mt-10 flex gap-4 justify-center">
              <Button size="lg" className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90">
                Get Started
              </Button>
              <Button variant="outline" size="lg">
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-primary">Why Synapse AI?</h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Experience the next generation of AI-powered research and interaction
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Brain className="h-8 w-8" />}
              title="Real-Time AI Knowledge Retrieval"
              description="Instantly access and analyze verified knowledge with AI-driven real-time research capabilities."
            />
            <FeatureCard
              icon={<Lock className="h-8 w-8" />}
              title="Blockchain-Verified AI Trust Score"
              description="Ensure credibility with a trust layer powered by blockchain, verifying every piece of information AI delivers."
            />
            <FeatureCard
              icon={<Network className="h-8 w-8" />}
              title="AI Knowledge Graphs & Debate Bot"
              description="Explore structured knowledge maps and engage in intelligent debates with an AI-driven debate assistant."
            />
            <FeatureCard
              icon={<Glasses className="h-8 w-8" />}
              title="Holographic AI Assistant"
              description="Step into the future with an immersive AI assistant that interacts in AR/VR, revolutionizing how you engage with information."
            />
            <FeatureCard
              icon={<Video className="h-8 w-8" />}
              title="AI-Generated Video Reports"
              description="Transform research findings into dynamic, AI-generated video reports for easy interpretation and sharing."
            />
            <FeatureCard
              icon={<BarChart3 className="h-8 w-8" />}
              title="Advanced Analytics"
              description="Gain deep insights with comprehensive analytics and visualization tools powered by AI."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background via-primary/5 to-primary/10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-6">
            The Future of Research is Here
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Synapse AI is built for researchers, professionals, and innovators who seek AI transparency, real-time insights, and verifiable knowledge. Experience an AI that not only retrieves information but ensures its authenticity and credibility.
          </p>
          <Button size="lg" className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90">
            Join the AI-Powered Research Revolution Today!
          </Button>
        </div>
      </section>
    </main>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <Card className="group hover:shadow-lg transition-all duration-300 overflow-hidden border-primary/10">
      <CardHeader>
        <div className="mx-auto rounded-full bg-gradient-to-br from-primary/10 to-blue-600/10 p-4 w-fit group-hover:scale-110 transition-transform duration-300">
          <div className="text-primary">{icon}</div>
        </div>
        <CardTitle className="mt-4 text-xl group-hover:text-primary transition-colors duration-300">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-base">
          {description}
        </CardDescription>
      </CardContent>
    </Card>
  );
}